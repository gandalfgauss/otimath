/**
 * teams.js
 * --------
 * Os 20 times brasileiros do OVA original (Fase1.as).
 * Cada time tem:
 *   id        — chave única (slug)
 *   nome      — nome exibido ao aluno (como no enunciado)
 *   escudo    — caminho para a imagem em /public/assets/escudos/
 */
export const teams = [
  { id: "america-rn",     nome: "América",            escudo: "/assets/escudos/america-rn.png" },
  { id: "atletico-mg",    nome: "Atlético Mineiro",   escudo: "/assets/escudos/atletico-mg.png" },
  { id: "atletico-pr",    nome: "Atlético Paranaense",escudo: "/assets/escudos/atletico-pr.png" },
  { id: "avai",           nome: "Avaí",               escudo: "/assets/escudos/avai.png" },
  { id: "botafogo",       nome: "Botafogo",           escudo: "/assets/escudos/botafogo.png" },
  { id: "corinthians",    nome: "Corinthians",        escudo: "/assets/escudos/corinthians.png" },
  { id: "coritiba",       nome: "Coritiba",           escudo: "/assets/escudos/coritiba.png" },
  { id: "cruzeiro",       nome: "Cruzeiro",           escudo: "/assets/escudos/cruzeiro.png" },
  { id: "flamengo",       nome: "Flamengo",           escudo: "/assets/escudos/flamengo.png" },
  { id: "fluminense",     nome: "Fluminense",         escudo: "/assets/escudos/fluminense.png" },
  { id: "goias",          nome: "Goiás",              escudo: "/assets/escudos/goias.png" },
  { id: "gremio",         nome: "Grêmio",             escudo: "/assets/escudos/gremio.png" },
  { id: "internacional",  nome: "Internacional",      escudo: "/assets/escudos/internacional.png" },
  { id: "nautico",        nome: "Náutico",            escudo: "/assets/escudos/nautico.png" },
  { id: "palmeiras",      nome: "Palmeiras",          escudo: "/assets/escudos/palmeiras.png" },
  { id: "santos",         nome: "Santos",             escudo: "/assets/escudos/santos.png" },
  { id: "sao-paulo",      nome: "São Paulo",          escudo: "/assets/escudos/sao-paulo.png" },
  { id: "sport",          nome: "Sport",              escudo: "/assets/escudos/sport.png" },
  { id: "vasco",          nome: "Vasco",              escudo: "/assets/escudos/vasco.png" },
  { id: "vitoria",        nome: "Vitória",            escudo: "/assets/escudos/vitoria.png" },
];

/**
 * Sorteia DOIS times distintos (time1 e time2).
 * Espelha o comportamento de sorteiaTime() em Fase1.as, mas garante distinção.
 */
export function sortearDoisTimes() {
  const idx1 = Math.floor(Math.random() * teams.length);
  let idx2;
  do {
    idx2 = Math.floor(Math.random() * teams.length);
  } while (idx2 === idx1);
  return [teams[idx1], teams[idx2]];
}
