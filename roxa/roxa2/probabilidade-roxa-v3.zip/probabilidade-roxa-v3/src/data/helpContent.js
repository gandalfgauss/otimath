/**
 * helpContent.js
 * --------------
 * Conteúdo didático dos 5 tutoriais da tela de Ajuda, fiel aos textos
 * decompilados do SWF original (pasta /texts).
 * Mantém o encadeamento de páginas por tópico e a metáfora-fio-condutor
 * da urna com 12 bolas (3 roxas, 4 vermelhas, 5 amarelas).
 */
export const helpContent = {
  geral: {
    titulo: "Probabilidade — Noções Gerais",
    paginas: [
      {
        h: "Experimentos aleatórios",
        p: "A probabilidade trabalha com experimentos aleatórios. Esses são os experimentos que, mesmo repetidos várias vezes e nas mesmas condições, geram resultados diferentes. Eles estão sujeitos à lei do acaso, assim os resultados não serão previsíveis, mesmo que haja um grande número de repetições do mesmo fenômeno.",
        exemplos: "Exemplos: lançamento de uma moeda, lançamento de um dado, determinação da vida útil de um componente eletrônico, previsão do tempo, sorteios, etc.",
      },
      {
        h: "Espaço amostral",
        p: "O Espaço Amostral é o conjunto de todos os resultados possíveis de um experimento aleatório. Geralmente esse conjunto é indicado por U ou S.",
        exemplos: "1) Jogar um dado e observar o número da face que ficar para cima: S = {1, 2, 3, 4, 5, 6}, n(S) = 6.\n2) Jogar uma moeda: S = {cara, coroa}, n(S) = 2.",
      },
      {
        h: "Evento",
        p: "Um evento é qualquer subconjunto de um espaço amostral S. Ou seja, dentre os resultados possíveis que fazem parte do Espaço Amostral, existem os subconjuntos de eventos que podem ocorrer.",
        exemplos: "No lançamento do dado, caso o resultado seja um número par, as opções seriam 2, 4 ou 6. Assim, o evento \"ocorrência de um número par\" é o subconjunto E = {2, 4, 6}, n(E) = 3.\nAo lançar uma moeda, o evento \"tirar cara\" seria E = {cara}, n(E) = 1.",
      },
      {
        h: "Probabilidade de um evento",
        p: "A probabilidade P(E) de um evento equiprovável ocorrer é dada pela razão (divisão) entre o número de casos favoráveis (subconjunto do espaço amostral) pelo número total de casos possíveis (espaço amostral). A probabilidade de um evento E é um número compreendido entre 0 e 1, que indica a chance de ocorrência do evento.",
        formula: "P(E) = \\dfrac{n(E)}{n(S)} = \\dfrac{\\text{número de casos favoráveis}}{\\text{número de casos possíveis}}",
        exemplos: "A um evento impossível atribui-se probabilidade zero; a um evento certo, probabilidade 1. As probabilidades podem ser expressas por frações, decimais ou porcentagens. Por exemplo, 1/10 = 0,1 = 10%.",
      },
    ],
  },

  umEvento: {
    titulo: "Probabilidade de um Evento Ocorrer",
    paginas: [
      {
        h: "Metáfora da urna",
        p: "Considere uma urna que contém 12 bolas: 3 ROXAS, 4 VERMELHAS e 5 AMARELAS. Vamos calcular a probabilidade de retirar, ao acaso, uma bola de cada cor.",
        formula: "P(E) = \\dfrac{n(E)}{n(S)}",
      },
      {
        h: "Evento V: bola vermelha",
        p: "EVENTO (V): Ao retirar uma bola, esta ser da cor VERMELHA.",
        calculo: "P(V) = \\dfrac{\\text{bolas vermelhas}}{\\text{total de bolas}} = \\dfrac{4}{12} = \\dfrac{1}{3} \\approx 0{,}33 = 33{,}33\\%",
      },
      {
        h: "Evento A: bola amarela",
        p: "EVENTO (A): Ao retirar uma bola, esta ser da cor AMARELA.",
        calculo: "P(A) = \\dfrac{5}{12} \\approx 0{,}41 = 41{,}66\\%",
      },
      {
        h: "Evento R: bola roxa",
        p: "EVENTO (R): Ao retirar uma bola, esta ser da cor ROXA.",
        calculo: "P(R) = \\dfrac{3}{12} = \\dfrac{1}{4} = 0{,}25 = 25\\%",
      },
    ],
  },

  uniao: {
    titulo: "Probabilidade da União de Dois Eventos",
    paginas: [
      {
        h: "Definição",
        p: "Se A e B são eventos em um mesmo espaço amostral S, A ∪ B é o evento que ocorre se, e somente se, ocorre o Evento A ou ocorre o Evento B.",
        formula: "P(A \\cup B) = P(A) + P(B) - P(A \\cap B)",
      },
      {
        h: "Exemplo",
        p: "EVENTO (Y): Ao retirar uma bola, esta ser da cor VERMELHA OU DE NÚMERO 2. Y é a união de dois eventos: ser vermelha OU ser de número 2.",
        exemplos: "P(V): Bolas vermelhas → {1, 2, 3, 4}\nP(D): Bolas de número 2 → {2A, 2V, 2R}",
      },
      {
        h: "Cuidado com a interseção",
        p: "Note que SER VERMELHA pode COINCIDIR com SER DE NÚMERO 2. Assim, os eventos NÃO são mutuamente excludentes, e deve-se levar este fato em consideração ao calcular a probabilidade: ao somar os dois eventos, estaríamos contando duas vezes a bola vermelha DE número 2. Para eliminar este erro, subtrai-se a bola 2 (interseção entre os dois eventos) por aparecer em ambos simultaneamente.",
        calculo: "P(Y) = P(V \\cup D) = P(V) + P(D) - P(V \\cap D) = \\dfrac{4}{12} + \\dfrac{3}{12} - \\dfrac{1}{12} = \\dfrac{6}{12} = 0{,}5 = 50\\%",
      },
    ],
  },

  sucessivos: {
    titulo: "Probabilidade de Eventos Sucessivos ou Simultâneos",
    paginas: [
      {
        h: "Eventos independentes",
        p: "A probabilidade de ocorrer um evento e sucessivamente outro é dada pelo produto das probabilidades individuais, quando há reposição (eventos independentes).",
        formula: "P(A \\cap R) = P(A) \\cdot P(R)",
      },
      {
        h: "Exemplo com reposição",
        p: "EVENTO (W): Retirar uma bola e registrar sua cor. Repor a bola na urna e realizar uma nova retirada. Calcular a probabilidade da cor da 1ª retirada ser AMARELA e da 2ª ser ROXA.",
        calculo: "P(A \\cap R) = P(A) \\cdot P(R) = \\dfrac{5}{12} \\cdot \\dfrac{3}{12} = \\dfrac{15}{144} = \\dfrac{5}{48} \\approx 0{,}1041 = 10{,}41\\%",
      },
      {
        h: "Quando a ordem não importa",
        p: "Se o enunciado pedir \"uma bola amarela e uma roxa\" sem fixar a ordem, existe também a sequência (Roxa, Amarela) com mesma probabilidade P₂ = 10,41%.",
        calculo: "P = P_1 + P_2 = 10{,}41\\% + 10{,}41\\% = 20{,}82\\%",
      },
    ],
  },

  condicional: {
    titulo: "Probabilidade Condicional",
    paginas: [
      {
        h: "Definição",
        p: "A probabilidade de um evento na certeza da ocorrência de um evento anterior. Dados dois eventos A e B de um espaço amostral S, a probabilidade de B ocorrer, sabendo que A já ocorreu, é:",
        formula: "P(B \\mid A) = \\dfrac{P(A \\cap B)}{P(A)}",
      },
      {
        h: "Exemplo",
        p: "EVENTO (Z): Ao retirar uma bola e esta ser de cor ROXA, qual a probabilidade de ser de número 1?\n\nPrimeiro evento: ser de cor roxa → P(R).\nSegundo evento: ser de número 1 → P(n₁).",
        calculo: "P(n_1 \\mid R) = \\dfrac{P(n_1 \\cap R)}{P(R)}",
      },
    ],
  },
};

/**
 * Mapeamento: dado o tipo de questão (0..3), qual tópico da ajuda
 * abrir ao errar. Corresponde a mostrarTutorialErrou() em Fase1.as.
 */
export const topicoPorTipoDeQuestao = {
  0: "umEvento",
  1: "uniao",
  2: "condicional",    // no AS3 original o tipo 2 (P(homem ∩ Time2)) abre a aba condicional
  3: "sucessivos",
};
