import React, { useState } from "react";
import TelaInicial from "./screens/TelaInicial.jsx";
import Fase1       from "./screens/Fase1.jsx";
import Creditos    from "./screens/Creditos.jsx";
import HelpModal   from "./components/HelpModal.jsx";

/**
 * App — controlador de telas do OVA.
 * Espelha o comportamento do ProbabilidadeRoxa.as (bootstrap do SWF)
 * e do TelaIniciar.as (tela de entrada).
 */
export default function App() {
  const [screen,    setScreen]    = useState("inicial"); // "inicial" | "fase1" | "creditos"
  const [helpOpen,  setHelpOpen]  = useState(false);
  const [helpTopic, setHelpTopic] = useState("geral");

  function openHelp(topic = "geral") {
    setHelpTopic(topic);
    setHelpOpen(true);
  }

  return (
    <>
      <a href="#conteudo" className="skip-link">Pular para o conteúdo</a>

      {screen === "inicial" && (
        <TelaInicial
          onStart={() => setScreen("fase1")}
          onCredits={() => setScreen("creditos")}
        />
      )}
      {screen === "fase1" && (
        <Fase1 onHelp={openHelp} />
      )}
      {screen === "creditos" && (
        <Creditos onBack={() => setScreen("inicial")} />
      )}

      {/* Botão de "home" flutuante quando não estiver na inicial */}
      {screen !== "inicial" && (
        <button
          type="button"
          className="btn-cartoon small ghost"
          onClick={() => setScreen("inicial")}
          style={{
            position: "fixed",
            top: "16px", left: "16px",
            zIndex: 10,
          }}
          aria-label="Voltar para tela inicial"
        >
          ← Início
        </button>
      )}

      <HelpModal
        open={helpOpen}
        topic={helpTopic}
        setTopic={setHelpTopic}
        onClose={() => setHelpOpen(false)}
      />
    </>
  );
}
