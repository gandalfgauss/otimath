import React, { useEffect, useRef, useState } from "react";
import { comVirgula } from "../logic/probability";

/**
 * SpiralAlternatives — animação em espiral das 5 alternativas.
 *
 * Replica FIELMENTE a função posicionaBolas() de Fase1.as:
 *   - 5 alternativas partem do CENTRO (mesma posição da bola)
 *   - A cada frame: contTimer += 2
 *   - Raio: raio = contTimer * 50/180 (cresce linearmente)
 *   - Ângulo por alternativa i:
 *       angulo_i = ((contTimer + i*72 - 18) / 180) * PI
 *   - x = centro.x + cos(angulo_i) * raio
 *   - y = centro.y + sin(angulo_i) * raio
 *   - Limite: 180 frames (Timer(1, 180) no AS3)
 *
 * No AS3 original, o timer rodava a 1ms (velocidade máxima do Flash Player
 * ≈ 60fps). Aqui usamos requestAnimationFrame para suavidade igual/melhor.
 */
export default function SpiralAlternatives({
  question,
  selectedIdx,
  onSelect,
  center = { x: 240, y: 240 },
  frameLimit = 180,
  finalRadius = 180,
}) {
  const [contTimer, setContTimer] = useState(0);
  const rafRef = useRef(null);
  const startRef = useRef(null);

  useEffect(() => {
    setContTimer(0);
    startRef.current = null;

    function step(ts) {
      if (!startRef.current) startRef.current = ts;
      // Avança contTimer +2 por frame, como no AS3
      setContTimer((prev) => {
        const next = prev + 2;
        if (next >= frameLimit * 2) return frameLimit * 2;
        return next;
      });
      // Continua enquanto não chegou ao limite
      if (rafRef.current !== null) {
        rafRef.current = requestAnimationFrame(step);
      }
    }

    rafRef.current = requestAnimationFrame(step);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [question]);

  // Fator de escala do raio: a fórmula original levaria o raio a
  // (2*180)*50/180 = 100px. Ampliamos para `finalRadius` para caber
  // com folga no layout moderno.
  const scale = finalRadius / 100;
  const raio = contTimer * (50 / 180) * scale;

  // Parar a animação quando chegar ao final (mas manter posição)
  useEffect(() => {
    if (contTimer >= frameLimit * 2 && rafRef.current) {
      cancelAnimationFrame(rafRef.current);
      rafRef.current = null;
    }
  }, [contTimer, frameLimit]);

  return (
    <div
      role="radiogroup"
      aria-label="Alternativas da questão"
      style={{
        position: "relative",
        width: `${center.x * 2}px`,
        height: `${center.y * 2}px`,
        margin: "0 auto",
        maxWidth: "100%",
      }}
    >
      {question.alternativas.map((alt, i) => {
        // Fórmula original do Flash (em radianos)
        const angulo = ((contTimer + i * 72 - 18) / 180) * Math.PI;
        const x = center.x + Math.cos(angulo) * raio;
        const y = center.y + Math.sin(angulo) * raio;
        const selected = selectedIdx === i;
        return (
          <button
            key={i}
            role="radio"
            aria-checked={selected}
            aria-label={`Alternativa ${i + 1}: ${comVirgula(alt)}`}
            className={`spiral-alt ${selected ? "selected" : ""}`}
            style={{ left: `${x}px`, top: `${y}px`, border: 0 }}
            onClick={() => onSelect(i)}
          >
            {comVirgula(alt)}
          </button>
        );
      })}
    </div>
  );
}
