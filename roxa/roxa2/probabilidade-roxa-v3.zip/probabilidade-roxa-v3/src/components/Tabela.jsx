import React from "react";

/**
 * Tabela de contingência — réplica moderna de Tabela_12 do SWF original
 * com EXTENSÃO DIDÁTICA: linha "TOTAL" com inputs editáveis pelo aluno.
 *
 * Estados visuais dos inputs:
 *   - normal:    borda tracejada rosa, fundo branco
 *   - wrong:     fundo vermelho + shake (após "Soma errada!")
 *   - right:     fundo verde (após "Totais corretos!")
 *   - locked:    desabilitado quando passou da fase de leitura
 */
export default function Tabela({ question, totals, setTotals, locked, somaResult }) {
  const { time1, time2, H1, H2, M1, M2 } = question;

  function update(key, raw) {
    const val = raw.replace(/[^\d]/g, "").slice(0, 4);
    setTotals({ ...totals, [key]: val });
  }

  function classFor(key) {
    if (locked) return "tot-input right";
    if (somaResult && somaResult[key] === false) return "tot-input wrong";
    if (somaResult && somaResult[key] === true)  return "tot-input right";
    return "tot-input";
  }

  return (
    <div className="panel-silver">
      <div className="panel-silver-inner" style={{ padding: "8px" }}>
        <table className="tabela-contingencia">
          <caption className="sr-only">
            Espaço amostral: torcedores entrevistados. O aluno deve preencher
            os totais marginais e o total geral antes de responder.
          </caption>
          <thead>
            <tr>
              <th className="corner" scope="col" aria-label="vazio"></th>
              <th scope="col" aria-label="masculino">
                <span className="gender-male" aria-hidden="true">♂</span>
              </th>
              <th scope="col" aria-label="feminino">
                <span className="gender-female" aria-hidden="true">♀</span>
              </th>
              <th scope="col">Total</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <th scope="row" className="team-cell">
                <img src={time1.escudo} alt={`Escudo do ${time1.nome}`} />
                <div style={{ fontSize: "11px", marginTop: "2px" }}>{time1.nome}</div>
              </th>
              <td className="num">{H1}</td>
              <td className="num">{M1}</td>
              <td>
                <input className={classFor("t1")} value={totals.t1} disabled={locked}
                  onChange={(e) => update("t1", e.target.value)}
                  aria-label={`Total de torcedores do ${time1.nome}`}
                  inputMode="numeric" placeholder="?" />
              </td>
            </tr>
            <tr>
              <th scope="row" className="team-cell">
                <img src={time2.escudo} alt={`Escudo do ${time2.nome}`} />
                <div style={{ fontSize: "11px", marginTop: "2px" }}>{time2.nome}</div>
              </th>
              <td className="num">{H2}</td>
              <td className="num">{M2}</td>
              <td>
                <input className={classFor("t2")} value={totals.t2} disabled={locked}
                  onChange={(e) => update("t2", e.target.value)}
                  aria-label={`Total de torcedores do ${time2.nome}`}
                  inputMode="numeric" placeholder="?" />
              </td>
            </tr>
            <tr>
              <th scope="row" style={{
                fontFamily: "var(--font-display)", fontSize: "12px",
                background: "linear-gradient(180deg, #fff 0%, #c0c0c0 100%)"
              }}>
                TOTAL
              </th>
              <td>
                <input className={classFor("th")} value={totals.th} disabled={locked}
                  onChange={(e) => update("th", e.target.value)}
                  aria-label="Total de torcedores do sexo masculino"
                  inputMode="numeric" placeholder="?" />
              </td>
              <td>
                <input className={classFor("tm")} value={totals.tm} disabled={locked}
                  onChange={(e) => update("tm", e.target.value)}
                  aria-label="Total de torcedoras do sexo feminino"
                  inputMode="numeric" placeholder="?" />
              </td>
              <td>
                <input className={classFor("tg")} value={totals.tg} disabled={locked}
                  onChange={(e) => update("tg", e.target.value)}
                  aria-label="Total geral (espaço amostral)"
                  inputMode="numeric" placeholder="?" />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  );
}
