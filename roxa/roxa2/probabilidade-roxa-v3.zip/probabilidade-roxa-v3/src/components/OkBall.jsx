import React from "react";

/**
 * OkBall — bola de futebol com "Ok" estampado, botão de submeter resposta.
 * Inspirada no MovieClip "bola" do Fase1.as (símbolo 109 do SWF).
 * O usuário seleciona uma alternativa na espiral e CLICA NA BOLA para confirmar.
 */
export default function OkBall({ onClick, disabled, pulse }) {
  const classes = ["ok-ball"];
  if (disabled) classes.push("disabled");
  if (pulse) classes.push("pulse");

  return (
    <button
      type="button"
      className={classes.join(" ")}
      onClick={onClick}
      disabled={disabled}
      aria-label="Confirmar resposta"
      style={{
        background: "none", border: 0, padding: 0,
        display: "grid", placeItems: "center",
      }}
    >
      <svg viewBox="0 0 120 120" width="120" height="120" aria-hidden="true">
        <defs>
          <radialGradient id="ring-grad" cx="50%" cy="50%" r="50%">
            <stop offset="70%" stopColor="#ffffff" />
            <stop offset="85%" stopColor="#b0b0b0" />
            <stop offset="100%" stopColor="#505050" />
          </radialGradient>
          <radialGradient id="ball-grad" cx="40%" cy="35%" r="60%">
            <stop offset="0%"  stopColor="#ffffff" />
            <stop offset="60%" stopColor="#eaeaea" />
            <stop offset="100%" stopColor="#8a8a8a" />
          </radialGradient>
          <filter id="shad" x="-50%" y="-50%" width="200%" height="200%">
            <feDropShadow dx="0" dy="3" stdDeviation="3" floodOpacity="0.4"/>
          </filter>
        </defs>
        {/* Anel metálico externo */}
        <circle cx="60" cy="60" r="58" fill="url(#ring-grad)" />
        <circle cx="60" cy="60" r="52" fill="#1a1a1a" />
        {/* Bola de futebol */}
        <circle cx="60" cy="60" r="48" fill="url(#ball-grad)" />
        {/* Hexágonos pretos (padrão de bola) */}
        <g fill="#1a1a1a" opacity="0.9">
          <polygon points="60,28 72,36 70,50 50,50 48,36" />
          <polygon points="30,56 44,50 54,62 46,74 32,70" />
          <polygon points="90,56 76,50 66,62 74,74 88,70" />
          <polygon points="60,78 46,74 50,90 70,90 74,74" />
        </g>
        {/* Linhas conectoras */}
        <g stroke="#1a1a1a" strokeWidth="1.5" fill="none" opacity="0.6">
          <path d="M 60 28 L 60 18" />
          <path d="M 30 56 L 15 52" />
          <path d="M 90 56 L 105 52" />
          <path d="M 60 90 L 60 105" />
        </g>
        {/* Texto "Ok" */}
        <text x="60" y="68" textAnchor="middle"
          fontFamily="Alfa Slab One, Impact, sans-serif"
          fontSize="30" fill="#e53935"
          stroke="#fff" strokeWidth="2" paintOrder="stroke"
          filter="url(#shad)">Ok</text>
      </svg>
    </button>
  );
}
