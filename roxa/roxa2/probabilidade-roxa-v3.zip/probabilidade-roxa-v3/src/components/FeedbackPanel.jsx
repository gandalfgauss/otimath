import React from "react";
import { comVirgula } from "../logic/probability";

/**
 * FeedbackPanel — exibe "RESPOSTA CERTA" ou "RESPOSTA ERRADA" como nos
 * MovieClips respostaCerta/respostaErrada do OVA original. EXTENSÕES:
 *   - Resolução passo a passo (o Flash original mostrava só certo/errado).
 *   - Animação de gol em CSS quando acerta (estádio + bola + texto GOOOL!).
 */
function GolAnim() {
  return (
    <div className="estadio" aria-hidden="true">
      <div className="bola-anim"></div>
      <div className="gol-text">GOOOL!</div>
    </div>
  );
}

export default function FeedbackPanel({ result, question, onNext, onHelp }) {
  if (!result) return null;
  const correct = result.correct;

  return (
    <div className={`feedback-card ${correct ? "correct" : "wrong"}`}>
      <div className="feedback-card-inner" role="status" aria-live="polite">
        <h3>{correct ? "✓ Resposta Certa!" : "✗ Resposta Errada"}</h3>
        {correct && <GolAnim />}
        <p style={{ margin: "0 0 14px 0", fontSize: "15px" }}>
          {correct
            ? "Parabéns — você marcou o gol! 🥅⚽"
            : `A resposta correta era ${comVirgula(question.respostaCerta)}.`}
        </p>

        <details
          open={!correct}
          style={{
            textAlign: "left",
            background: "#f9f5f7",
            padding: "10px 14px",
            borderRadius: "8px",
            marginBottom: "14px",
            border: "1px solid #ecd5e0",
          }}
        >
          <summary style={{
            cursor: "pointer",
            fontFamily: "var(--font-display)",
            color: "var(--pink-700)",
            fontSize: "13px",
            letterSpacing: "0.08em",
          }}>
            📖 Ver resolução passo a passo
          </summary>
          <ol style={{ margin: "10px 0 0 0", paddingLeft: "20px", fontSize: "14px", lineHeight: 1.6 }}>
            {question.passos.map((p, i) => (
              <li key={i} style={{ marginBottom: "6px" }}>{p}</li>
            ))}
          </ol>
          <div style={{ marginTop: "10px", padding: "8px 10px", background: "#fff",
            borderRadius: "4px", fontFamily: "monospace", fontSize: "13px" }}>
            Fórmula: {question.formula}
          </div>
        </details>

        <div style={{ display: "flex", gap: "10px", justifyContent: "center", flexWrap: "wrap" }}>
          <button type="button" className="btn-cartoon" onClick={onNext}>
            Próxima questão →
          </button>
          {!correct && (
            <button type="button" className="btn-cartoon ghost" onClick={onHelp}>
              📚 Revisar conceito
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
