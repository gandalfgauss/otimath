import React, { useEffect, useRef, useState } from "react";
import { helpContent } from "../data/helpContent";

const TOPICS = [
  { id: "geral",       label: "GERAL" },
  { id: "umEvento",    label: "EVENTO" },
  { id: "uniao",       label: "UNIÃO" },
  { id: "sucessivos",  label: "SUCESSIVOS" },
  { id: "condicional", label: "CONDICIONAL" },
];

/**
 * Renderiza expressão matemática "LaTeX-like" usando Unicode.
 * Substituição simples — sem dependência de KaTeX para manter o bundle leve.
 * (Em versão com KaTeX basta trocar este componente.)
 */
function Math({ expr }) {
  if (!expr) return null;
  const formatted = expr
    .replace(/\\dfrac\{([^}]+)\}\{([^}]+)\}/g, "($1)/($2)")
    .replace(/\\cdot/g, "·")
    .replace(/\\cap/g, "∩")
    .replace(/\\cup/g, "∪")
    .replace(/\\mid/g, "|")
    .replace(/\\Omega/g, "Ω")
    .replace(/\\approx/g, "≈")
    .replace(/\\text\{([^}]+)\}/g, "$1")
    .replace(/\\#/g, "#")
    .replace(/\\,/g, " ")
    .replace(/\\%/g, "%")
    .replace(/\\\\/g, "");
  return <span className="formula">{formatted}</span>;
}

export default function HelpModal({ open, topic, setTopic, onClose }) {
  const [pageIdx, setPageIdx] = useState(0);
  const dialogRef = useRef(null);
  const firstBtnRef = useRef(null);

  // Reset página ao trocar tópico
  useEffect(() => { setPageIdx(0); }, [topic]);

  // ESC fecha
  useEffect(() => {
    if (!open) return;
    function onKey(e) {
      if (e.key === "Escape") onClose();
      if (e.key === "ArrowRight") nextPage();
      if (e.key === "ArrowLeft")  prevPage();
    }
    window.addEventListener("keydown", onKey);
    // Foco no botão de fechar ao abrir
    setTimeout(() => firstBtnRef.current?.focus(), 50);
    return () => window.removeEventListener("keydown", onKey);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, topic, pageIdx]);

  if (!open) return null;

  const content = helpContent[topic] || helpContent.geral;
  const paginas = content.paginas || [];
  const pagina = paginas[pageIdx] || {};

  function nextPage() {
    if (pageIdx < paginas.length - 1) setPageIdx(pageIdx + 1);
  }
  function prevPage() {
    if (pageIdx > 0) setPageIdx(pageIdx - 1);
  }

  return (
    <div
      className="modal-backdrop"
      onClick={(e) => { if (e.target === e.currentTarget) onClose(); }}
    >
      <div
        ref={dialogRef}
        role="dialog"
        aria-modal="true"
        aria-labelledby="help-title"
        className="modal-help metal-frame"
      >
        <div className="metal-frame-inner modal-help-inner" style={{ padding: "16px" }}>
          {/* Cabeçalho */}
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "10px" }}>
            <h2 id="help-title" className="title-flash" style={{ fontSize: "24px", margin: 0 }}>
              📚 AJUDA
            </h2>
            <button
              ref={firstBtnRef}
              type="button"
              className="btn-cartoon small ghost"
              onClick={onClose}
              aria-label="Fechar ajuda"
            >
              ✕ Fechar
            </button>
          </div>

          {/* Abas */}
          <div className="help-tabs" role="tablist">
            {TOPICS.map((t) => (
              <button
                key={t.id}
                role="tab"
                aria-selected={topic === t.id}
                className={`help-tab ${topic === t.id ? "active" : ""}`}
                onClick={() => setTopic(t.id)}
              >
                {t.label}
              </button>
            ))}
          </div>

          {/* Conteúdo */}
          <div className="help-body" role="tabpanel">
            <h3>{content.titulo}</h3>
            {pagina.h && <h4 style={{ margin: "0 0 8px 0", color: "var(--pink-600)" }}>{pagina.h}</h4>}
            {pagina.p && <p style={{ whiteSpace: "pre-line" }}>{pagina.p}</p>}
            {pagina.formula && <Math expr={pagina.formula} />}
            {pagina.calculo && <Math expr={pagina.calculo} />}
            {pagina.exemplos && <div className="examples">{pagina.exemplos}</div>}
          </div>

          {/* Paginação */}
          <div className="help-pagination">
            <button
              type="button"
              className="btn-cartoon small ghost"
              onClick={prevPage}
              disabled={pageIdx === 0}
              aria-label="Página anterior"
              style={{ visibility: pageIdx === 0 ? "hidden" : "visible" }}
            >
              ← Voltar
            </button>
            <div className="dots" aria-label={`Página ${pageIdx + 1} de ${paginas.length}`}>
              {paginas.map((_, i) => (
                <button
                  key={i}
                  type="button"
                  className={`dot ${i === pageIdx ? "active" : ""}`}
                  onClick={() => setPageIdx(i)}
                  aria-label={`Ir para página ${i + 1}`}
                />
              ))}
            </div>
            <button
              type="button"
              className="btn-cartoon small"
              onClick={nextPage}
              disabled={pageIdx === paginas.length - 1}
              aria-label="Próxima página"
              style={{ visibility: pageIdx === paginas.length - 1 ? "hidden" : "visible" }}
            >
              Avançar →
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
