import React, { useEffect, useRef, useState } from "react";

/**
 * Calculator — calculadora arrastável (drag-and-drop) com mouse e touch.
 * Operações: adição, subtração, divisão.
 *
 * O usuário pode arrastar a calculadora pela barra superior para reposicioná-la,
 * permitindo visualizar a tabela mesmo durante o uso. Funciona em desktop (mouse)
 * e em dispositivos móveis (touch). A posição é mantida dentro da viewport.
 */
const CALC_W = 246;
const CALC_H = 340;

export default function Calculator({ open, onClose }) {
  const [display, setDisplay]     = useState("0");
  const [prev, setPrev]           = useState(null);
  const [op, setOp]               = useState(null);
  const [justEval, setJustEval]   = useState(false);

  // === Estado de drag ===
  const [pos, setPos] = useState(() => {
    if (typeof window === "undefined") return { x: 16, y: 100 };
    return { x: 16, y: Math.max(60, window.innerHeight - CALC_H - 70) };
  });
  const [dragging, setDragging] = useState(false);
  const dragRef = useRef({ mx: 0, my: 0, sx: 0, sy: 0 });

  // Reposiciona se a viewport mudar de tamanho (mantém visível)
  useEffect(() => {
    function onResize() {
      setPos((p) => ({
        x: Math.max(0, Math.min(window.innerWidth - CALC_W, p.x)),
        y: Math.max(0, Math.min(window.innerHeight - CALC_H, p.y)),
      }));
    }
    window.addEventListener("resize", onResize);
    return () => window.removeEventListener("resize", onResize);
  }, []);

  function startDrag(e) {
    const point = e.touches ? e.touches[0] : e;
    dragRef.current = {
      mx: point.clientX, my: point.clientY,
      sx: pos.x,        sy: pos.y,
    };
    setDragging(true);
    if (e.cancelable) e.preventDefault();
  }

  useEffect(() => {
    if (!dragging) return;
    function onMove(e) {
      const point = e.touches ? e.touches[0] : e;
      const dx = point.clientX - dragRef.current.mx;
      const dy = point.clientY - dragRef.current.my;
      let nx = dragRef.current.sx + dx;
      let ny = dragRef.current.sy + dy;
      nx = Math.max(0, Math.min(window.innerWidth - CALC_W, nx));
      ny = Math.max(0, Math.min(window.innerHeight - CALC_H, ny));
      setPos({ x: nx, y: ny });
      if (e.cancelable) e.preventDefault();
    }
    function onEnd() { setDragging(false); }
    window.addEventListener("mousemove", onMove);
    window.addEventListener("mouseup", onEnd);
    window.addEventListener("touchmove", onMove, { passive: false });
    window.addEventListener("touchend", onEnd);
    window.addEventListener("touchcancel", onEnd);
    return () => {
      window.removeEventListener("mousemove", onMove);
      window.removeEventListener("mouseup", onEnd);
      window.removeEventListener("touchmove", onMove);
      window.removeEventListener("touchend", onEnd);
      window.removeEventListener("touchcancel", onEnd);
    };
  }, [dragging]);

  // === Lógica da calculadora ===
  const fmt = (n) => {
    if (!isFinite(n)) return "Erro";
    const s = (Math.round(n * 10000) / 10000).toString();
    return s.replace(".", ",");
  };
  const parse = (s) => parseFloat(s.replace(",", "."));

  function inputDigit(d) {
    if (justEval || display === "Erro") {
      setDisplay(d); setJustEval(false); return;
    }
    setDisplay(display === "0" ? d : display + d);
  }

  function inputDot() {
    if (justEval || display === "Erro") {
      setDisplay("0,"); setJustEval(false); return;
    }
    if (!display.includes(",")) setDisplay(display + ",");
  }

  function compute(a, b, oper) {
    switch (oper) {
      case "+": return a + b;
      case "-": return a - b;
      case "÷": return b === 0 ? NaN : a / b;
      default:  return b;
    }
  }

  function setOperator(newOp) {
    const cur = parse(display);
    if (prev !== null && op !== null && !justEval) {
      const r = compute(prev, cur, op);
      setDisplay(fmt(r));
      setPrev(r);
    } else {
      setPrev(cur);
    }
    setOp(newOp);
    setJustEval(true);
  }

  function evaluate() {
    if (prev === null || op === null) return;
    const cur = parse(display);
    const r = compute(prev, cur, op);
    setDisplay(fmt(r));
    setPrev(null);
    setOp(null);
    setJustEval(true);
  }

  function clearAll() {
    setDisplay("0"); setPrev(null); setOp(null); setJustEval(false);
  }

  function backspace() {
    if (justEval || display === "Erro" || display.length <= 1) {
      setDisplay("0"); setJustEval(false); return;
    }
    setDisplay(display.slice(0, -1));
  }

  if (!open) return null;

  return (
    <div
      className="calc-popup"
      role="dialog"
      aria-label="Calculadora (arraste pela barra superior para mover)"
      style={{ left: pos.x, top: pos.y, bottom: "auto" }}
    >
      <div className="calc-inner">
        <div
          className={"calc-header" + (dragging ? " dragging" : "")}
          onMouseDown={startDrag}
          onTouchStart={startDrag}
          style={{ cursor: dragging ? "grabbing" : "grab", touchAction: "none" }}
          aria-label="Barra de arrastar"
        >
          <span>⋮⋮ 🧮 CALCULADORA</span>
          <button
            className="calc-close"
            onClick={onClose}
            aria-label="Fechar calculadora"
          >
            ✕
          </button>
        </div>

        <div className="calc-display" aria-live="polite">{display}</div>

        <div className="calc-grid">
          <button className="calc-btn fn" onClick={clearAll}>AC</button>
          <button className="calc-btn fn" onClick={backspace} aria-label="Apagar último dígito">⌫</button>
          <button className="calc-btn fn" disabled style={{ opacity: 0.3 }}> </button>
          <button className="calc-btn op" onClick={() => setOperator("÷")}>÷</button>

          <button className="calc-btn" onClick={() => inputDigit("7")}>7</button>
          <button className="calc-btn" onClick={() => inputDigit("8")}>8</button>
          <button className="calc-btn" onClick={() => inputDigit("9")}>9</button>
          <button className="calc-btn op" onClick={() => setOperator("-")}>−</button>

          <button className="calc-btn" onClick={() => inputDigit("4")}>4</button>
          <button className="calc-btn" onClick={() => inputDigit("5")}>5</button>
          <button className="calc-btn" onClick={() => inputDigit("6")}>6</button>
          <button className="calc-btn op" onClick={() => setOperator("+")}>+</button>

          <button className="calc-btn" onClick={() => inputDigit("1")}>1</button>
          <button className="calc-btn" onClick={() => inputDigit("2")}>2</button>
          <button className="calc-btn" onClick={() => inputDigit("3")}>3</button>
          <button className="calc-btn eq" style={{ gridRow: "span 2" }} onClick={evaluate}>=</button>

          <button className="calc-btn" style={{ gridColumn: "span 2" }} onClick={() => inputDigit("0")}>0</button>
          <button className="calc-btn" onClick={inputDot}>,</button>
        </div>
      </div>
    </div>
  );
}
