import React from "react";

/**
 * QuestionPanel — painel branco com o enunciado da questão.
 * O TIPO da questão NÃO é mais exibido ao aluno (a identificação é
 * feita internamente apenas para roteamento da ajuda contextual).
 */
export default function QuestionPanel({ question, children }) {
  return (
    <div className="question-panel">
      <p style={{ margin: 0, fontSize: "16px" }}>{question.enunciado}</p>
      {children}
    </div>
  );
}
