import { sortearDoisTimes } from "../data/teams";

/**
 * probability.js
 * --------------
 * Lógica das 4 questões do OVA, fiel ao original Fase1.as (ActionScript 3).
 *
 * Convenções:
 *   - Total = H1 + H2 + M1 + M2  (homens e mulheres de cada time)
 *   - Truncagem em 2 casas decimais: Math.floor(x * 100) / 100
 *     (IMPORTANTE: é truncagem, não arredondamento — como no AS3 original)
 *   - Separador decimal: vírgula (pt-BR)
 */

/** Trunca em 2 casas — replica Math.floor(x*100)/100 do AS3 */
export const trunc2 = (x) => Math.floor(x * 100) / 100;

/** Formata decimal com vírgula */
export const comVirgula = (x) => String(trunc2(x)).replace(".", ",");

/** Gera quantidade aleatória de torcedores (0..50) como em Fase1.as */
const qtdAleatoria = () => Math.round(Math.random() * 50);

/** Gera um distrator "próximo mas incorreto", como em sortearAlternativas() */
function gerarDistratorProximo(respCerta) {
  // Fórmula do AS3: Number(param1) * Math.random() * 3 (depois trunca)
  const base = parseFloat(respCerta);
  let v;
  let tentativa = 0;
  do {
    v = trunc2(base * Math.random() * 3);
    tentativa++;
  } while ((v === base || v < 0 || v > 1) && tentativa < 20);
  // fallback se não conseguiu
  if (v === base || v < 0 || v > 1) v = trunc2(Math.random());
  return v;
}

/**
 * Cria uma questão completa com espaço amostral, enunciado,
 * resposta correta e alternativas (5: 1 correta + 4 distratoras).
 */
export function criarQuestao() {
  const [time1, time2] = sortearDoisTimes();
  const H1 = qtdAleatoria();
  const H2 = qtdAleatoria();
  const M1 = qtdAleatoria();
  const M2 = qtdAleatoria();
  const total = H1 + H2 + M1 + M2;

  // Garante total mínimo para evitar divisão por zero / questões triviais
  // (no original o total 0 travaria; aqui re-sorteamos se for muito baixo)
  if (total < 10) {
    return criarQuestao();
  }

  const tipo = Math.floor(Math.random() * 4);

  let enunciado;
  let respNum;
  let formula;
  let passos;

  switch (tipo) {
    case 0: {
      // Evento simples: P(mulher)
      enunciado = `Qual é a probabilidade de se entrevistar, ao acaso, uma pessoa do sexo feminino?`;
      respNum = (M1 + M2) / total;
      formula = `P(F) = \\dfrac{n(F)}{n(S)}`;
      passos = [
        `Identificamos o evento F = "ser do sexo feminino".`,
        `Número de casos favoráveis: n(F) = ${M1} + ${M2} = ${M1 + M2}.`,
        `Número total de casos possíveis (espaço amostral): n(S) = ${H1} + ${H2} + ${M1} + ${M2} = ${total}.`,
        `Portanto, P(F) = ${M1 + M2} / ${total} ≈ ${comVirgula(respNum)}.`,
      ];
      break;
    }
    case 1: {
      // União: P(Time1 OU homem)
      enunciado = `Se uma pessoa é entrevistada ao acaso, qual é a probabilidade dela ser da torcida do ${time1.nome} OU do sexo masculino?`;
      // P(T1 ∪ M) = (H1 + H2 + M1) / total
      // Explicação:  P(T1) + P(M) - P(T1 ∩ M)
      //            = (H1+M1)/T + (H1+H2)/T - H1/T
      //            = (H1+H2+M1) / T
      respNum = (H1 + H2 + M1) / total;
      formula = `P(A \\cup B) = P(A) + P(B) - P(A \\cap B)`;
      passos = [
        `Evento A = "torcer pelo ${time1.nome}"; Evento B = "ser homem".`,
        `P(A) = ${H1 + M1}/${total} (torcedores do ${time1.nome}).`,
        `P(B) = ${H1 + H2}/${total} (homens no total).`,
        `P(A ∩ B) = ${H1}/${total} (homens torcedores do ${time1.nome}).`,
        `P(A ∪ B) = ${H1 + M1}/${total} + ${H1 + H2}/${total} − ${H1}/${total} = ${H1 + H2 + M1}/${total} ≈ ${comVirgula(respNum)}.`,
      ];
      break;
    }
    case 2: {
      // Interseção / condicional: P(homem E Time2)
      enunciado = `Se uma pessoa é entrevistada ao acaso, qual é a probabilidade dela ser do sexo masculino E ser torcedor do ${time2.nome}?`;
      respNum = H2 / total;
      formula = `P(A \\cap B) = \\dfrac{n(A \\cap B)}{n(S)}`;
      passos = [
        `Queremos pessoas que atendem às DUAS condições: ser homem E torcer pelo ${time2.nome}.`,
        `Número de casos favoráveis: n(A ∩ B) = ${H2} (homens do ${time2.nome}).`,
        `Espaço amostral: n(S) = ${total}.`,
        `Portanto, P(A ∩ B) = ${H2} / ${total} ≈ ${comVirgula(respNum)}.`,
      ];
      break;
    }
    case 3:
    default: {
      // Sucessivos com reposição
      enunciado = `Se duas pessoas são entrevistadas na sequência, qual é a probabilidade da primeira ser um HOMEM do ${time1.nome} e da segunda ser uma MULHER do ${time2.nome}? (A mesma pessoa pode ser entrevistada duas vezes.)`;
      respNum = (H1 / total) * (M2 / total);
      formula = `P(A \\cap B) = P(A) \\cdot P(B)`;
      passos = [
        `Eventos sucessivos COM reposição ⇒ eventos independentes.`,
        `Evento A = "1ª pessoa é homem do ${time1.nome}": P(A) = ${H1}/${total}.`,
        `Evento B = "2ª pessoa é mulher do ${time2.nome}": P(B) = ${M2}/${total}.`,
        `Como A e B são independentes: P(A ∩ B) = P(A) × P(B) = (${H1}/${total}) × (${M2}/${total}) ≈ ${comVirgula(respNum)}.`,
      ];
      break;
    }
  }

  const respostaCerta = trunc2(respNum);

  // Gera 5 alternativas: 1 correta + 4 distratoras (como em sortearAlternativas)
  const posCorreta = Math.floor(Math.random() * 5);
  const alternativas = [];
  const usadas = new Set([respostaCerta]);
  for (let i = 0; i < 5; i++) {
    if (i === posCorreta) {
      alternativas.push(respostaCerta);
    } else {
      let d;
      let tent = 0;
      do {
        d = gerarDistratorProximo(respostaCerta);
        tent++;
      } while (usadas.has(d) && tent < 20);
      usadas.add(d);
      alternativas.push(d);
    }
  }

  return {
    tipo,
    time1,
    time2,
    H1, H2, M1, M2, total,
    enunciado,
    formula,
    passos,
    respostaCerta,
    alternativas,
    posCorreta,
  };
}
