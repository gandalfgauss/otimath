import React from "react";

/**
 * Creditos — tela de créditos com os nomes da equipe CONDIGITAL/Cruzeiro do Sul
 * (extraídos dos textos originais 476.txt / 477.txt) + autoria da reconstrução.
 */
export default function Creditos({ onBack }) {
  return (
    <main id="conteudo" className="stage-bg" style={{ minHeight: "100vh", padding: "24px" }}>
      <div style={{ maxWidth: "900px", margin: "0 auto", position: "relative", zIndex: 2 }}>
        <div className="metal-frame">
          <div className="metal-frame-inner" style={{ padding: "28px" }}>

            <h1 className="title-flash" style={{ fontSize: "clamp(40px, 6vw, 68px)", textAlign: "center", margin: "0 0 8px 0" }}>
              CRÉDITOS
            </h1>
            <p style={{
              textAlign: "center",
              color: "#fff",
              fontFamily: "var(--font-display)",
              textShadow: "2px 2px 0 #5a0836",
              fontSize: "14px",
              letterSpacing: "0.1em",
              margin: "0 0 24px 0",
            }}>
              PROBABILIDADE ROXA
            </p>

            {/* Reconstrução moderna */}
            <section style={{
              background: "linear-gradient(180deg, #fff0f7 0%, #ffd6e8 100%)",
              color: "#5a0836",
              padding: "20px 24px",
              borderRadius: "14px",
              marginBottom: "20px",
              border: "3px solid #fff",
              boxShadow: "inset 0 2px 0 rgba(255,255,255,0.9)",
            }}>
              <h2 style={{ fontFamily: "var(--font-display)", margin: "0 0 10px 0", color: "var(--pink-700)", fontSize: "18px" }}>
                RECONSTRUÇÃO EM REACT (2026)
              </h2>
              <p style={{ margin: "0 0 8px 0", lineHeight: 1.5, fontSize: "15px" }}>
                <strong>Rangel Freitas dos Santos</strong> — Mestrando PROFMAT/UFVJM.
              </p>
              <p style={{ margin: 0, fontSize: "13px", lineHeight: 1.5 }}>
                Reconstrução fiel do OVA original em React 18, preservando a
                estética visual, a mecânica de jogo e os conteúdos pedagógicos,
                sob licença Creative Commons. Parte da dissertação{" "}
                <em>"Explorando o Acaso: uma sequência didática interativa para o
                ensino de Probabilidade no Ensino Médio"</em>.
              </p>
            </section>

            {/* Equipe original CONDIGITAL */}
            <section style={{
              background: "rgba(255,255,255,0.95)",
              color: "#1a1a1a",
              padding: "20px 24px",
              borderRadius: "14px",
              marginBottom: "20px",
            }}>
              <h2 style={{ fontFamily: "var(--font-display)", margin: "0 0 14px 0", color: "var(--pink-700)", fontSize: "16px" }}>
                EQUIPE ORIGINAL — PROJETO CONDIGITAL
              </h2>

              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: "14px", fontSize: "14px", lineHeight: 1.5 }}>
                <div>
                  <strong style={{ color: "var(--pink-600)" }}>COORDENAÇÃO</strong>
                  <div>Ismar Frango Silveira</div>
                  <div>Carlos Fernando de Araújo Jr.</div>
                </div>
                <div>
                  <strong style={{ color: "var(--pink-600)" }}>PRODUÇÃO</strong>
                  <div>Leonardo C. C. Kasperavičius</div>
                  <div>Rachel Lucien Miranda</div>
                </div>
                <div>
                  <strong style={{ color: "var(--pink-600)" }}>EQUIPE DE SOFTWARE</strong>
                  <div>Daniel Sueda de Moraes</div>
                  <div>Daniel de Abreu Lessi</div>
                  <div>Daniel Eiji Ishikawa Sasaki</div>
                  <div>Guilherme F. da Silva Kawano</div>
                  <div>Marcelo Higa</div>
                  <div>Otávio Ireno da Silva</div>
                  <div>Thiago Jacinto Nunes Ferreira</div>
                </div>
                <div>
                  <strong style={{ color: "var(--pink-600)" }}>CONTEUDISTAS</strong>
                  <div>Jaime Sandro da Veiga (gerência)</div>
                  <div>Adriana Domingues Freitas</div>
                  <div>Carlos Alberto de Campos</div>
                  <div>Edson Pereira Gonzaga</div>
                </div>
                <div>
                  <strong style={{ color: "var(--pink-600)" }}>APOIO PEDAGÓGICO</strong>
                  <div>Ana Lúcia Tinoco Cabral</div>
                  <div>Ivan Carlos A. de Oliveira</div>
                  <div>Pollyana Notargiacomo Mustaro</div>
                  <div>Rita Maria Lino Tarcia</div>
                </div>
              </div>
            </section>

            {/* Instituições */}
            <section style={{
              background: "rgba(255,255,255,0.9)",
              color: "#1a1a1a",
              padding: "16px 24px",
              borderRadius: "14px",
              marginBottom: "20px",
              textAlign: "center",
              fontSize: "13px",
            }}>
              <p style={{ margin: "0 0 10px 0", color: "var(--pink-700)", fontWeight: 700, fontFamily: "var(--font-display)", letterSpacing: "0.06em" }}>
                PROJETO CONDIGITAL — UNIVERSIDADE CRUZEIRO DO SUL
              </p>
              <p style={{ margin: 0, opacity: 0.8 }}>
                Realização: MEC / SEED / FNDE / Brasil. Licença Creative Commons (CC BY).
              </p>
            </section>

            <div style={{ textAlign: "center" }}>
              <button type="button" className="btn-cartoon" onClick={onBack}>
                ← Voltar ao início
              </button>
            </div>

          </div>
        </div>
      </div>
    </main>
  );
}
