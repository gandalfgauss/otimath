import React, { useState } from "react";
import { criarQuestao } from "../logic/probability";
import Tabela from "../components/Tabela";
import QuestionPanel from "../components/QuestionPanel";
import OkBall from "../components/OkBall";
import SpiralAlternatives from "../components/SpiralAlternatives";
import FeedbackPanel from "../components/FeedbackPanel";
import Calculator from "../components/Calculator";
import { topicoPorTipoDeQuestao } from "../data/helpContent";

/**
 * Fase1 — tela principal do jogo, fiel ao Fase1.as do SWF original
 * com EXTENSÃO DIDÁTICA: o aluno preenche os totais da tabela ANTES
 * de poder responder (reforça espaço amostral). Se a soma estiver
 * errada, mostra "Soma errada!" e bloqueia o avanço.
 *
 * Máquina de estados:
 *   "reading"    → aluno lê enunciado + preenche totais.
 *                  Botão "Responder":
 *                    se totais corretos → "choosing" + animação espiral.
 *                    se errados → "Soma errada!" e permanece em reading.
 *   "choosing"   → alternativas em espiral. Aluno seleciona + clica na bola.
 *   "revealed"   → respostaCerta / respostaErrada + resolução + animação gol.
 */
export default function Fase1({ onHelp }) {
  const [question, setQuestion]   = useState(() => criarQuestao());
  const [phase, setPhase]         = useState("reading");
  const [selectedIdx, setSelIdx]  = useState(null);
  const [result, setResult]       = useState(null);
  const [stats, setStats]         = useState({ respondidas: 0, acertos: 0 });

  // Totais digitados pelo aluno
  const [totals, setTotals]         = useState({ t1: "", t2: "", th: "", tm: "", tg: "" });
  const [somaResult, setSomaResult] = useState(null);
  const [somaMsg, setSomaMsg]       = useState(null);   // null | "ok" | "errada"
  const [calcOpen, setCalcOpen]     = useState(false);

  // Totais corretos esperados
  const totaisCorretos = {
    t1: question.H1 + question.M1,
    t2: question.H2 + question.M2,
    th: question.H1 + question.H2,
    tm: question.M1 + question.M2,
    tg: question.total,
  };

  function tentarResponder() {
    const r = {
      t1: parseInt(totals.t1, 10) === totaisCorretos.t1,
      t2: parseInt(totals.t2, 10) === totaisCorretos.t2,
      th: parseInt(totals.th, 10) === totaisCorretos.th,
      tm: parseInt(totals.tm, 10) === totaisCorretos.tm,
      tg: parseInt(totals.tg, 10) === totaisCorretos.tg,
    };
    setSomaResult(r);
    if (r.t1 && r.t2 && r.th && r.tm && r.tg) {
      setSomaMsg("ok");
      setTimeout(() => {
        setPhase("choosing");
        setSelIdx(null);
        setSomaMsg(null);
      }, 700);
    } else {
      setSomaMsg("errada");
    }
  }

  function confirmarResposta() {
    if (selectedIdx === null) return;
    const certa = selectedIdx === question.posCorreta;
    setResult({ correct: certa });
    setPhase("revealed");
    setStats((s) => ({
      respondidas: s.respondidas + 1,
      acertos:     s.acertos + (certa ? 1 : 0),
    }));
  }

  function proximaQuestao() {
    setQuestion(criarQuestao());
    setSelIdx(null);
    setResult(null);
    setTotals({ t1: "", t2: "", th: "", tm: "", tg: "" });
    setSomaResult(null);
    setSomaMsg(null);
    setPhase("reading");
  }

  function abrirAjudaContextual() {
    // Fiel ao mostrarTutorialErrou() do Fase1.as
    const topico = topicoPorTipoDeQuestao[question.tipo] || "geral";
    onHelp(topico);
  }

  const aproveitamento = stats.respondidas
    ? Math.round((stats.acertos / stats.respondidas) * 100)
    : 0;

  return (
    <main id="conteudo" className="stage-bg" style={{ minHeight: "100vh", padding: "16px" }}>
      <div style={{ maxWidth: "1100px", margin: "0 auto", position: "relative", zIndex: 2 }}>
        {/* Estatísticas */}
        <div style={{
          display: "flex", gap: "10px", flexWrap: "wrap",
          marginBottom: "16px", alignItems: "center", justifyContent: "center",
        }}>
          <span className="stat-chip">Respondidas <strong>{stats.respondidas}</strong></span>
          <span className="stat-chip">Acertos <strong>{stats.acertos}</strong></span>
          <span className="stat-chip">Aproveit. <strong>{aproveitamento}%</strong></span>
        </div>

        <div className="metal-frame">
          <div className="metal-frame-inner" style={{ padding: "24px" }}>
            <div className="responsive-grid" style={{
              display: "grid",
              gridTemplateColumns: "minmax(340px, 440px) 1fr",
              gap: "24px",
              alignItems: "start",
            }}>
              {/* === Coluna esquerda: tabela com inputs === */}
              <div>
                <Tabela
                  question={question}
                  totals={totals}
                  setTotals={(t) => {
                    setTotals(t);
                    setSomaResult(null);
                    setSomaMsg(null);
                  }}
                  locked={phase !== "reading"}
                  somaResult={somaResult}
                />
                {phase === "reading" && (
                  <div style={{ textAlign: "center", marginTop: "8px" }}>
                    {somaMsg === "errada" && <div className="soma-aviso">⚠ Soma errada!</div>}
                    {somaMsg === "ok"     && <div className="soma-ok">✓ Totais corretos!</div>}
                  </div>
                )}
              </div>

              {/* === Coluna direita: enunciado + interação === */}
              <div style={{ minHeight: "400px" }}>
                {phase === "reading" && (
                  <>
                    <QuestionPanel question={question} />
                    <p style={{
                      textAlign: "center",
                      fontFamily: "var(--font-display)",
                      color: "#fff",
                      textShadow: "2px 2px 0 #5a0836",
                      fontSize: "13px",
                      margin: "16px 0 8px 0",
                      letterSpacing: "0.05em",
                    }}>
                      1. PREENCHA OS TOTAIS DA TABELA. &nbsp; 2. CLIQUE EM RESPONDER.
                    </p>
                    <div style={{ display: "flex", gap: "12px", marginTop: "16px",
                      justifyContent: "center", flexWrap: "wrap" }}>
                      <button type="button" className="btn-cartoon" onClick={tentarResponder}>
                        ⚽ Responder
                      </button>
                      <button type="button" className="btn-cartoon ghost" onClick={() => onHelp("geral")}>
                        ? Ajuda
                      </button>
                    </div>
                  </>
                )}

                {phase === "choosing" && (
                  <>
                    <QuestionPanel question={question} />
                    <p style={{
                      textAlign: "center",
                      fontFamily: "var(--font-display)",
                      color: "#fff",
                      textShadow: "2px 2px 0 #5a0836",
                      fontSize: "13px",
                      margin: "16px 0 8px 0",
                      letterSpacing: "0.05em",
                    }}>
                      1. TOQUE NA ALTERNATIVA QUE QUISER. &nbsp; 2. CLIQUE NA BOLA PARA CONFIRMAR.
                    </p>
                    <div style={{ position: "relative", marginTop: "8px" }}>
                      <div style={{
                        position: "absolute",
                        left: "50%", top: "50%",
                        transform: "translate(-50%, -50%)",
                        zIndex: 2,
                      }}>
                        <OkBall
                          onClick={confirmarResposta}
                          disabled={selectedIdx === null}
                          pulse={selectedIdx !== null}
                        />
                      </div>
                      <SpiralAlternatives
                        question={question}
                        selectedIdx={selectedIdx}
                        onSelect={setSelIdx}
                        center={{ x: 220, y: 220 }}
                        finalRadius={170}
                      />
                    </div>
                  </>
                )}

                {phase === "revealed" && (
                  <>
                    <QuestionPanel question={question} />
                    <div style={{ marginTop: "16px" }}>
                      <FeedbackPanel
                        result={result}
                        question={question}
                        onNext={proximaQuestao}
                        onHelp={abrirAjudaContextual}
                      />
                    </div>
                  </>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Botão Ajuda flutuante */}
        <button
          type="button"
          className="btn-cartoon small ghost"
          onClick={() => onHelp("geral")}
          style={{
            position: "fixed",
            bottom: "20px", right: "20px",
            zIndex: 10,
          }}
          aria-label="Abrir painel de ajuda"
        >
          ? AJUDA
        </button>

        {/* Botão Calculadora flutuante */}
        <button
          type="button"
          className="btn-cartoon small"
          onClick={() => setCalcOpen(!calcOpen)}
          style={{
            position: "fixed",
            bottom: "20px", left: "20px",
            zIndex: 10,
          }}
          aria-label={calcOpen ? "Fechar calculadora" : "Abrir calculadora"}
        >
          🧮 {calcOpen ? "Fechar" : "Calc."}
        </button>

        <Calculator open={calcOpen} onClose={() => setCalcOpen(false)} />
      </div>

      <style>{`
        @media (max-width: 760px) {
          .responsive-grid { grid-template-columns: 1fr !important; }
        }
      `}</style>
    </main>
  );
}
