import React from "react";
import OkBall from "../components/OkBall";

export default function TelaInicial({ onStart, onCredits }) {
  return (
    <main
      id="conteudo"
      className="stage-bg"
      style={{ minHeight: "100vh", display: "grid", placeItems: "center", padding: "24px" }}
    >
      <div style={{ textAlign: "center", position: "relative", zIndex: 2 }}>
        {/* Título em estilo Flash */}
        <h1
          className="title-flash"
          style={{
            fontSize: "clamp(48px, 9vw, 110px)",
            lineHeight: 0.95,
            margin: "0 0 8px 0",
          }}
        >
          PROBABILIDADE
        </h1>
        <h1
          className="title-flash"
          style={{
            fontSize: "clamp(52px, 10vw, 130px)",
            lineHeight: 0.95,
            margin: "0 0 24px 0",
            letterSpacing: "0.08em",
          }}
        >
          ROXA
        </h1>

        <p style={{
          fontFamily: "var(--font-display)",
          fontSize: "clamp(14px, 2vw, 18px)",
          letterSpacing: "0.15em",
          color: "#fff",
          textShadow: "2px 2px 0 #5a0836, 0 0 20px rgba(255,79,163,0.8)",
          margin: "0 0 40px 0",
        }}>
          OVA CONDIGITAL • reconstrução PROFMAT/UFVJM
        </p>

        {/* Bola decorativa animada */}
        <div style={{ display: "grid", placeItems: "center", marginBottom: "32px" }}>
          <div className="ok-ball pulse" style={{ cursor: "default" }} aria-hidden="true">
            <OkBall onClick={() => {}} disabled pulse={false} />
          </div>
        </div>

        {/* Botões */}
        <div style={{
          display: "flex", gap: "16px", justifyContent: "center", flexWrap: "wrap",
        }}>
          <button type="button" className="btn-cartoon" onClick={onStart} style={{ fontSize: "22px", padding: "18px 40px" }}>
            ▶ JOGAR
          </button>
          <button type="button" className="btn-cartoon ghost" onClick={onCredits}>
            ⚽ CRÉDITOS
          </button>
        </div>

        {/* Sub-info */}
        <p style={{
          marginTop: "40px",
          fontSize: "13px",
          color: "rgba(255,255,255,0.75)",
          maxWidth: "480px",
          margin: "40px auto 0",
          lineHeight: 1.5,
        }}>
          Calcule probabilidades em situações de torcida! Interprete tabelas,
          combine eventos e marque o gol da resposta certa.
        </p>
      </div>
    </main>
  );
}
