# Probabilidade Roxa — v3.0 (Reconstrução Fiel)

**Reconstrução em React 18 + Vite** do OVA *Probabilidade Roxa* (CONDIGITAL/MEC, Universidade Cruzeiro do Sul), a partir dos arquivos ActionScript 3 e dos assets PNG/SVG extraídos diretamente do SWF original.

Esta versão prioriza **fidelidade visual e pedagógica** ao original Flash: paleta rosa-magenta vibrante, molduras metalizadas, escudos reais dos 20 clubes, bola de futebol com "Ok", animação das alternativas em espiral a partir do centro e conteúdos didáticos transcritos dos textos originais.

Projeto acadêmico vinculado à dissertação  
**"Explorando o Acaso: uma sequência didática interativa para o ensino de Probabilidade no Ensino Médio"**  
PROFMAT/UFVJM — autoria de Rangel Freitas dos Santos.

---

## 1. Como executar

Requisitos: Node.js ≥ 18.

```bash
cd probabilidade-roxa-v3
npm install
npm run dev
# abre em http://localhost:5173
```

Para gerar build de produção:

```bash
npm run build       # gera dist/
npm run preview     # pré-visualiza o build
```

O `base: "./"` em `vite.config.js` permite servir o build a partir de qualquer subdiretório (ideal para incorporar em Moodle via SCORM ou como recurso estático).

---

## 2. Fidelidade ao original Flash

| Elemento no SWF original (`Fase1.as`, `Ajuda.as`, assets)            | Implementação em React                                    |
| -------------------------------------------------------------------- | --------------------------------------------------------- |
| Paleta rosa-magenta + molduras prateadas metálicas                   | Variáveis CSS `--pink-*`, `--silver-*`, classe `metal-frame` |
| Fonte *Showcard Gothic* (título)                                      | Google Fonts **Bungee** + **Alfa Slab One** (estilo próximo) |
| 20 clubes com escudos reais (imagens decompiladas `20.png`, `26.png`…) | `public/assets/escudos/*.png` (nomes-slug)                |
| Bola de futebol com "Ok" (sprite `Bola_20`)                           | `<OkBall />` em SVG inline (vetor + efeitos)              |
| Tabela de contingência com ♂/♀ + escudos                               | `<Tabela />` com `<caption>` sr-only e `scope`             |
| `posicionaBolas()` — espiral que cresce (`contTimer*50/180`, 180 frames) | `<SpiralAlternatives />` com `requestAnimationFrame`       |
| Seleção: alternativa brilha dourada (`gotoAndStop("brilho")`)         | Classe `.spiral-alt.selected` com animação `glow`          |
| Confirmação: clica na BOLA para submeter                              | `<OkBall onClick={confirmar} />`                          |
| `respostaCerta` / `respostaErrada` (MovieClips)                       | `<FeedbackPanel correct/wrong />` com gradiente verde/vermelho |
| `mostrarTutorialErrou()` — abre aba específica da ajuda ao errar      | `topicoPorTipoDeQuestao[tipo]` + `onHelp(topico)`          |
| 5 abas de ajuda (Geral/Evento/União/Sucessivos/Condicional)           | `<HelpModal />` com conteúdos transcritos dos textos `/texts/*.txt` do SWF |
| Navegação ⇦/⇨ nas abas (`avancar/voltar`)                              | Botões + setas do teclado + dots de paginação             |
| Créditos com equipe CONDIGITAL                                         | `<Creditos />` com nomes do `texts/476.txt`                |

### Lógica matemática (preservada byte a byte)

```
Total = H1 + H2 + M1 + M2

tipo 0:  P(mulher)         = (M1 + M2)   / Total
tipo 1:  P(Time1 ∪ homem)  = (H1+H2+M1)  / Total      ⟵ = P(A)+P(B)-P(A∩B)
tipo 2:  P(homem ∩ Time2)  = H2          / Total
tipo 3:  P(H_T1, depois M_T2 com reposição) = (H1/Total) · (M2/Total)

Truncagem: Math.floor(x * 100) / 100     (pt-BR com vírgula)
```

---

## 3. Estrutura de pastas

```
probabilidade-roxa-v3/
├── index.html
├── package.json
├── vite.config.js
├── README.md
├── public/
│   └── assets/
│       ├── escudos/        ← 20 PNGs extraídos do SWF
│       ├── bola-ok.png     ← sprite bola+"Ok" original
│       ├── bola-futebol.svg← vetor da bola (shape 1 do SWF)
│       ├── textura-diagonal.svg ← fundo (shape 487)
│       ├── frames-gol/     ← 6 frames da animação de gol
│       └── logos/          ← FNDE, MEC, Cruzeiro do Sul, CC-BY
└── src/
    ├── main.jsx            ← entry React 18
    ├── App.jsx             ← roteador de telas
    ├── styles.css          ← paleta rosa + molduras + estilos globais
    │
    ├── data/
    │   ├── teams.js        ← 20 times com slug + escudo
    │   └── helpContent.js  ← textos didáticos (transcrição fiel)
    │
    ├── logic/
    │   └── probability.js  ← lógica das 4 questões + distratores
    │
    ├── components/
    │   ├── Tabela.jsx              ← espaço amostral com ♂/♀
    │   ├── QuestionPanel.jsx       ← painel branco com enunciado
    │   ├── OkBall.jsx              ← bola de futebol com "Ok"
    │   ├── SpiralAlternatives.jsx  ← animação em espiral
    │   ├── FeedbackPanel.jsx       ← feedback certo/errado + resolução
    │   └── HelpModal.jsx           ← 5 abas de ajuda com paginação
    │
    └── screens/
        ├── TelaInicial.jsx  ← entrada: título + Jogar / Créditos
        ├── Fase1.jsx        ← o jogo (reading → choosing → revealed)
        └── Creditos.jsx     ← equipe original + autoria da reconstrução
```

---

## 4. Articulação com a BNCC

| Habilidade     | Descrição resumida                                                                 |
| -------------- | ---------------------------------------------------------------------------------- |
| **EM13MAT310** | Resolver problemas de probabilidade condicional em situações cotidianas, aplicando a Lei da Multiplicação e utilizando diagramas e árvores. |
| **EM13MAT311** | Identificar e descrever o espaço amostral de eventos aleatórios, realizando contagem das possibilidades e cálculo de probabilidade. |

Os quatro tipos de questão do OVA cobrem as operações fundamentais sobre eventos (simples, união, interseção, sucessivos independentes) exigidas por essas duas habilidades.

---

## 5. Extensões em relação ao original

A reconstrução é **fiel**, mas adiciona quatro camadas pedagógicas que o Flash original não tinha:

1. **Resolução passo a passo** ao revelar a resposta (original mostrava só certo/errado).
2. **Estatísticas de desempenho** em tempo real (respondidas, acertos, aproveitamento).
3. **Acessibilidade WCAG 2.1 AA**: skip-link, `role="radiogroup"`, `role="dialog"`, navegação por teclado (ESC / ← →), `aria-live`, `prefers-reduced-motion`.
4. **Responsividade**: o grid de duas colunas colapsa para uma coluna em telas < 760 px (mobile-friendly).

---

## 6. Próximas extensões sugeridas

- [ ] Substituir o renderizador "math-like" por **KaTeX** para LaTeX real.
- [ ] Adicionar tipo 5: **eventos sucessivos SEM reposição** (discussão de dependência).
- [ ] Banco externo de questões em JSON (abrir para outros professores adaptarem).
- [ ] Modo professor: parâmetros configuráveis (faixa de torcedores, tipos ativos).
- [ ] Exportação das estatísticas em CSV para análise pedagógica (DSR).
- [ ] Empacotamento como **SCORM 2004** para Moodle.

---

## 7. Créditos

### Reconstrução em React (2026)
**Rangel Freitas dos Santos** — PROFMAT / UFVJM

### OVA original (Projeto CONDIGITAL)
Realização: Universidade Cruzeiro do Sul — Incubadora de Jogos.  
Apoio: MEC / SEED / FNDE / Brasil.  
Coordenação: Ismar Frango Silveira e Carlos Fernando de Araújo Jr.  
Licença: Creative Commons BY (conforme `texts/436.txt` do SWF original).

---

> *"Explorando o Acaso: uma sequência didática interativa para o ensino de Probabilidade no Ensino Médio"* — dissertação em desenvolvimento no PROFMAT/UFVJM, 2026.
